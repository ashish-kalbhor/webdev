(function () {
    angular
        .module('FoodbookApp', ['ngRoute', 'ui.bootstrap']);
})();


